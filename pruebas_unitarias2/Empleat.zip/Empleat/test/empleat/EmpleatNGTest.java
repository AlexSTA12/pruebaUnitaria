/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package empleat;

import static org.testng.Assert.*;
import org.testng.annotations.Test;

/**
 *
 * @author Alexandru
 */
public class EmpleatNGTest {
    
    public EmpleatNGTest() {
    }

    /**
     * Test of calculaSalariBrut method, of class Empleat.
     */
    //@Test
    public void testCalculaSalariBrut() throws Exception {
        System.out.println("calculaSalariBrut");
        String tipusEmpleat = "encarregat";
        double vendesMes = 2500;
        int horesExtra = 2;
        Empleat instance = new Empleat();
        double expResult = 1737.14;
        double result = instance.calculaSalariBrut(tipusEmpleat, vendesMes, horesExtra);
        assertEquals(result, expResult, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of calculaSalariNet method, of class Empleat.
     */
    @Test
    public void testCalculaSalariNet() throws Exception {
        System.out.println("calculaSalariNet");
        double salariBrut = 500;
        Empleat instance = new Empleat();
        double expResult = 500;
        double result = instance.calculaSalariNet(salariBrut);
        assertEquals(result, expResult, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
