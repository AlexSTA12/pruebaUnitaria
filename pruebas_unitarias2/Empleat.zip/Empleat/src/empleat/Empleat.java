/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package empleat;

/**
 *
 * @author Alexandru
 */
public class Empleat {

    /**
     * @param args the command line arguments
     */
    public double calculaSalariBrut(String tipusEmpleat, double vendesMes, int horesExtra) throws MaException {
        if (tipusEmpleat == null || esEmpleat(tipusEmpleat)) { // SI es null o no es empleado, lanza la excepcion
            throw new MaException("el tipus de venedor no és correcte");
        }
        if (vendesMes < 0 || horesExtra < 0) { // Si vendesMes es negatiu o hores extra es negatiu, lanza la excepcion
            throw new MaException("el valor no pot ser negatiu");
        }
        int salariBase = 0;
        int prima = 0;
        if (tipusEmpleat.equals("venedor")) { 
            salariBase = 1000; // Aplica el salario de base 1000€
        } else if (tipusEmpleat.equals("encarregat")) {
            salariBase = 1500; // Aplica el salario de base 1500€
        }

        if (vendesMes >= 1000 && vendesMes < 2500) {
            prima = 100; // Aplica prima de 100€
        } else if (vendesMes >= 2500) {
            prima = 200; //Aplica prima de 200€
        }
        return salariBase + prima + (horesExtra * 18.57); // Devuelve el salario Bruto
        /*  tipusEmpleat no admite numeros o caracteres especiales a no ser que sea consonantes o vocales
         y que sea "encarregat" o "venedor".
            VendesMes no admite cadenas que no sea enteros o decimales
            horesExtra no admite cadenas, ni decimales que no sea enteros
        */
    }

    public double calculaSalariNet(double salariBrut) throws MaException {
        if (salariBrut < 0) { // Si el salario Bruto es negativo, lanza la excepcion
            throw new MaException("El salario bruto no puede ser negativo");
        }
        double retencio = 0;
        if (salariBrut >= 1000 && salariBrut <= 1500) {
            retencio = 0.16; // Aplica la retención de 16%
        } else if (salariBrut >= 1501) {
            retencio = 0.20; // Aplica la retencion de 20%
        }
        return salariBrut * (1 - retencio); //Devuelve el salario Neto
        // El "salariBrut no admite caracteres que no sea numeros y con o sin decimales
    }

    private boolean esEmpleat(String tipusEmpleat) {
        if (tipusEmpleat.equals("venedor")) { // Si es "venedor" no lanza la excepcion
            return false;
        }
        if (tipusEmpleat.equals("encarregat")) { // Si es "encarregat" no lanza la excepcion
            return false;
        }
        return true; // Si no es "venedor" o "encarregat" lanza excepcion
    }

}
