/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package vocals;

import static org.testng.Assert.*;
import org.testng.annotations.Test;

/**
 *
 * @author Alexandru
 */
public class VocalsNGTest {
    
    public VocalsNGTest() {
    }

    /**
     * Test of esVocal method, of class Vocals.
     */
    @Test
    public void testEsVocal() {
        System.out.println("esVocal");
        String lletra =  "á"; //No admite accentos, caracteres especiales, consonantes y numeros
        Vocals instance = new Vocals();
        boolean expResult = true;
        boolean result = instance.esVocal(lletra);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
